./hellminer -c stratum+tcp://ap.luckpool.net:3956#xnsub -u RJqkfLwxvTL5v8xA8N7vAn6Ajjh7NLjM3s.L01 -p x --cpu 2
